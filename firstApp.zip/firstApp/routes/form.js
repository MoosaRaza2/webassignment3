var express = require('express');
var router = express.Router();

var arr = [];

router.get('/faculty', function (req, res, next) {
  res.render('faculty', { faculty: arr })
})

router.post('/submit', function (req, res, next) {

  const { id, name, email, gender, street_address, city, country, course_code, phone_number } = req.body;

  const newFaculty = {
    name,
    id,
    gender,
    street_address,
    city,
    country,
    course_code,
    phone_number,
    email
  }
  arr.push(newFaculty)
  res.send(arr);
});

router.get('/:id', function (req, res) {
  const { id } = req.params

  const facultyMember = arr.find(faculty => faculty.id == id)

  res.status(200).json({
    status: 'success',
    facultyMember,
  });
})

router.post('/delete/:id', function (req, res) {
  const { id } = req.params

  arr = arr.filter((faculty => faculty.id !== id));

  res.status(200).json({
    status: 'success'
  });
})





module.exports = router;

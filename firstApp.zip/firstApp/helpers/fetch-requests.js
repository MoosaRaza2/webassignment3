var axios = require('axios');

function fetchCountries() {
   return axios.get('https://api.first.org/data/v1/countries').then((res)=>res.data)
}

module.exports = {
   fetchCountries
}